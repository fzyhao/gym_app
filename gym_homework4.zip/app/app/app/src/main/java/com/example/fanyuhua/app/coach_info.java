package com.example.fanyuhua.app;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class coach_info extends AppCompatActivity{
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.coaches);


        Button order2=(Button)findViewById(R.id.button13);
        Button order3=(Button)findViewById(R.id.button14);
        ImageView img1=(ImageView)findViewById(R.id.imageView3);
        ImageView img2=(ImageView)findViewById(R.id.imageView4);
        ImageView img3=(ImageView)findViewById(R.id.imageView5);

        Button order1=(Button)findViewById(R.id.button12);
        order1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               showdialog();
            }
        });

       order2.setOnClickListener(new View.OnClickListener(){
           public void onClick(View v){
               showdialog();
            }
        });
       order3.setOnClickListener(new View.OnClickListener(){
           public void onClick(View v){
               showdialog();
           }
       });
        img1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                showdialog1();
            }
        });
        img2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                showdialog2();
            }
        });
        img3.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                showdialog3();
            }
        });

   }


    private void showdialog(){
        //    通过AlertDialog.Builder这个类来实例化我们的一个AlertDialog的对象
        AlertDialog.Builder builder = new AlertDialog.Builder(coach_info.this);
        //    设置Title的图标

        //    设置Title的内容
        builder.setTitle("未查询到用户信息");
        //    设置Content来显示一个信息
        builder.setMessage("请先登录！");
        //    设置一个PositiveButton
        builder.setPositiveButton("登录", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                setContentView(R.layout.log_in);

            }
        });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.show();
    }

    private void showdialog1(){
        //    通过AlertDialog.Builder这个类来实例化我们的一个AlertDialog的对象
        AlertDialog.Builder builder = new AlertDialog.Builder(coach_info.this);
        //    设置Title的图标

        //    设置Title的内容
        builder.setTitle("教练a");
        //    设置Content来显示一个信息
        builder.setMessage("帅的一批！");
        //    设置一个PositiveButton

        builder.setNegativeButton("返回", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        builder.show();
    }

    private void showdialog2(){
        //    通过AlertDialog.Builder这个类来实例化我们的一个AlertDialog的对象
        AlertDialog.Builder builder = new AlertDialog.Builder(coach_info.this);
        //    设置Title的图标

        //    设置Title的内容
        builder.setTitle("教练b");
        //    设置Content来显示一个信息
        builder.setMessage("长的一般！");
        //    设置一个PositiveButton

        builder.setNegativeButton("返回", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        builder.show();
    }

    private void showdialog3(){
        //    通过AlertDialog.Builder这个类来实例化我们的一个AlertDialog的对象
        AlertDialog.Builder builder = new AlertDialog.Builder(coach_info.this);
        //    设置Title的图标

        //    设置Title的内容
        builder.setTitle("教练c");
        //    设置Content来显示一个信息
        builder.setMessage("丑的一批！");
        //    设置一个PositiveButton

        builder.setNegativeButton("返回", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        builder.show();
    }
}
